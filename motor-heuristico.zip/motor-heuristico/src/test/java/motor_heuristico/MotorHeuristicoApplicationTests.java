package motor_heuristico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MotorHeuristicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
