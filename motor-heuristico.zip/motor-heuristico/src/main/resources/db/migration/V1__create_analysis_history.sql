CREATE TABLE analysis_history (
                                  id SERIAL PRIMARY KEY,
                                  channel VARCHAR(50) NOT NULL,
                                  content TEXT NOT NULL,
                                  final_score DOUBLE PRECISION NOT NULL,
                                  is_malicious BOOLEAN NOT NULL,
                                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);