package motor_heuristico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MotorHeuristicoApplication {
	public static void main(String[] args) {
		SpringApplication.run(MotorHeuristicoApplication.class, args);
	}
}