package motor_heuristico.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "analysis_history")
public class AnalysisHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String channel;

    @Column(columnDefinition = "TEXT")
    private String content;

    @Column(name = "final_score")
    private double finalScore;

    @Column(name = "is_malicious")
    private boolean isMalicious;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;
}