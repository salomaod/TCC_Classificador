package motor_heuristico.model;

import lombok.Data;
import java.util.List;

@Data
public class AnalysisResult {
    private double finalScore;           // O Score final (S)
    private boolean isMalicious;         // A decisão do sistema (bloqueia ou liberta)
    private List<String> triggeredRules; // A lista de anomalias encontradas (explicabilidade)
}