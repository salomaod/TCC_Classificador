package motor_heuristico.model;

import lombok.Data;

@Data
public class AnalysisContext {
    private String content;
    private String channel;
}
