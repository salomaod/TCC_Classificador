package motor_heuristico.model;

import lombok.Data;
@Data
public class AnalysisRequest {

    private String content;
}
