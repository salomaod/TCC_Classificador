package motor_heuristico.rules;

import motor_heuristico.model.AnalysisContext;
import org.springframework.stereotype.Component;

@Component
public class SuspiciousLinkRule implements HeuristicRule {

    @Override
    public String getRuleName() {
        return "Presença de Link Suspeito/Encurtado";
    }

    @Override
    public double getWeight() {
        return 3.0;
    }

    @Override
    public boolean isTriggered(AnalysisContext context) {
        if (context.getContent() == null) return false;

        String text = context.getContent().toLowerCase();
        return text.contains("bit.ly") ||
                text.contains("tinyurl.com") ||
                text.contains("clickaqui");
    }
}