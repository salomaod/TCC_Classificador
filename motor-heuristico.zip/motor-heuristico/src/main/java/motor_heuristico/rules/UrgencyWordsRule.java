package motor_heuristico.rules;

import motor_heuristico.model.AnalysisContext;
import org.springframework.stereotype.Component;

@Component
public class UrgencyWordsRule implements HeuristicRule {

    @Override
    public String getRuleName() {
        return "Gatilho de Urgência e Ameaça Institucional";
    }

    @Override
    public double getWeight() {
        return 2.5;
    }

    @Override
    public boolean isTriggered(AnalysisContext context) {
        if (context.getContent() == null) return false;

        String text = context.getContent().toLowerCase();
        return text.contains("imediato") ||
                text.contains("bloqueado") ||
                text.contains("urgente") ||
                text.contains("cancelamento irrevogável") ||
                text.contains("sob pena de multa");
    }
}