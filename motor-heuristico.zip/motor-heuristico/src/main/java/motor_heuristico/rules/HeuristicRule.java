package motor_heuristico.rules;

import motor_heuristico.model.AnalysisContext;

public interface HeuristicRule {
    String getRuleName();
    double getWeight();
    boolean isTriggered(AnalysisContext context);
}