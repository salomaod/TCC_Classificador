package motor_heuristico.rules;

import motor_heuristico.model.AnalysisContext;
import org.springframework.stereotype.Component;

@Component
public class SpfFailureRule implements HeuristicRule {

    @Override
    public String getRuleName() {
        return "Falha de Autenticação de Domínio (SPF/DKIM)";
    }

    @Override
    public double getWeight() {
        return 3.5;
    }

    @Override
    public boolean isTriggered(AnalysisContext context) {
        if (!"EMAIL".equalsIgnoreCase(context.getChannel())) {
            return false;
        }

        if (context.getContent() == null) {
            return false;
        }

        String text = context.getContent().toLowerCase();
        return text.contains("spf=fail") || text.contains("dkim=fail");
    }
}