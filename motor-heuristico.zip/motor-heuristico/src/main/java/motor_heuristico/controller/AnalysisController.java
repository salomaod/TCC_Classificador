package motor_heuristico.controller;

import motor_heuristico.model.AnalysisContext;
import motor_heuristico.model.AnalysisHistory;
import motor_heuristico.model.AnalysisRequest;
import motor_heuristico.model.AnalysisResult;
import motor_heuristico.repository.AnalysisHistoryRepository;
import motor_heuristico.service.ScoringEngineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/analyze")
public class AnalysisController {

    private final ScoringEngineService scoringEngine;
    private final AnalysisHistoryRepository repository;

    @Autowired
    public AnalysisController(ScoringEngineService scoringEngine, AnalysisHistoryRepository repository) {
        this.scoringEngine = scoringEngine;
        this.repository = repository;
    }

    @PostMapping("/sms")
    public ResponseEntity<AnalysisResult> analyzeSms(@RequestBody AnalysisRequest request) {

        // 1. Prepara o contexto da análise
        AnalysisContext context = new AnalysisContext();
        context.setChannel("SMS");
        context.setContent(request.getContent());

        // 2. O Motor Heurístico calcula a nota
        AnalysisResult result = scoringEngine.analyze(context);

        // 3. Salva no PostgreSQL
        AnalysisHistory history = new AnalysisHistory();
        history.setChannel("SMS");
        history.setContent(request.getContent());
        history.setFinalScore(result.getFinalScore());
        history.setMalicious(result.isMalicious());
        repository.save(history);

        // 4. Devolve o resultado ao utilizador
        return ResponseEntity.ok(result);
    }
}