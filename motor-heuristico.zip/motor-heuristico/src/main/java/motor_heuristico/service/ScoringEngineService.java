package motor_heuristico.service;

import motor_heuristico.model.AnalysisContext;
import motor_heuristico.model.AnalysisResult;
import motor_heuristico.rules.HeuristicRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service

public class ScoringEngineService {
    // O Spring faz a "Injeção de Dependências" aqui.
    // Ele pega TODAS as classes que implementam HeuristicRule e coloca nesta lista automaticamente!
    private final List<HeuristicRule> rules;

    // O Limiar de corte (Threshold - T) que definimos no Capítulo 4 do TCC
    private static final double THRESHOLD = 5.0;

    @Autowired
    public ScoringEngineService(List<HeuristicRule> rules) {
        this.rules = rules;
    }

    public AnalysisResult analyze(AnalysisContext context) {
        double totalScore = 0.0;
        List<String> triggered = new ArrayList<>();

        // Itera sobre a lista de heurísticas (aqui ocorre o Somatório Matemático)
        for (HeuristicRule rule : rules) {
            if (rule.isTriggered(context)) {
                totalScore += rule.getWeight(); // w_i * 1
                triggered.add(rule.getRuleName() + " (Peso: " + rule.getWeight() + ")");
            }
        }

        // Monta o relatório final
        AnalysisResult result = new AnalysisResult();
        result.setFinalScore(totalScore);
        result.setMalicious(totalScore >= THRESHOLD);
        result.setTriggeredRules(triggered);

        return result;
    }
}
